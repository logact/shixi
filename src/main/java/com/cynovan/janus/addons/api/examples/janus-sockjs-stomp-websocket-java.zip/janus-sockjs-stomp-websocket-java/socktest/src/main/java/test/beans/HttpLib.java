package test.beans;

import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HttpLib {

    private static RequestConfig requestConfig = null;

    static {
        try {
            requestConfig = RequestConfig.custom()
                    .setConnectionRequestTimeout(3000)
                    .setSocketTimeout(3000)
                    .setConnectTimeout(3000)
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static CloseableHttpClient getConnection() {
        CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(SSLConnectionSocketFactory.getSocketFactory())
                // 设置请求配置
                .setDefaultRequestConfig(requestConfig)
                // 设置重试次数
                .setRetryHandler(new DefaultHttpRequestRetryHandler(0, false))
                .build();

        return httpClient;
    }

    public static JsonElement get(String url) {
        return get(url, null);
    }

    public static JsonElement get(String url, Map<String, String> params) {
        CloseableHttpClient httpclient = getConnection();
        CloseableHttpResponse responseBody = null;
        try {
            URIBuilder builder = new URIBuilder(url);
            if (params != null && !params.isEmpty()) {
                for (Entry<String, String> entry : params.entrySet()) {
                    builder.addParameter(entry.getKey(), entry.getValue());
                }
            }

            HttpGet httpget = new HttpGet(builder.build());
            responseBody = httpclient.execute(httpget);
            String value = EntityUtils.toString(responseBody.getEntity());
            JsonParser parser = new JsonParser();
            return parser.parse(value);
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            HttpClientUtils.closeQuietly(responseBody);
            HttpClientUtils.closeQuietly(httpclient);
        }
        return null;
    }

    public static JsonElement post(String url) {
        return post(url, null);
    }

    public static JsonElement post(String url, Map<String, String> params) {
        CloseableHttpClient httpclient = getConnection();
        CloseableHttpResponse responseBody = null;
        try {
            URIBuilder builder = new URIBuilder(url);
            HttpPost httppost = new HttpPost(builder.build());
            if (params != null && !params.isEmpty()) {
                List<NameValuePair> nameValuePairs = Lists.newArrayList();
                for (String key : params.keySet()) {
                    nameValuePairs.add(new BasicNameValuePair(key, params.get(key)));
                }
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
            }
            responseBody = httpclient.execute(httppost);
            String value = EntityUtils.toString(responseBody.getEntity());
            JsonParser parser = new JsonParser();
            return parser.parse(value);
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            HttpClientUtils.closeQuietly(responseBody);
            HttpClientUtils.closeQuietly(httpclient);
        }
        return null;
    }
}
