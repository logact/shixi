package test.beans;

import com.google.common.collect.Maps;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.Transport;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;

import javax.annotation.PostConstruct;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component
public class TestWebsocket {

    private final static WebSocketHttpHeaders headers = new WebSocketHttpHeaders();

    @Value("${ip}")
    private String ip;

    @Value("${port}")
    private Integer port;

    @Value("${token}")
    private String token;

    @Value("${uuid}")
    private String uuid;

    private class MyHandler extends StompSessionHandlerAdapter {
        public void afterConnected(StompSession stompSession, StompHeaders stompHeaders) {
            System.out.println("连接Websocket Server已成功");
        }
    }

    @PostConstruct
    public void getWebsocketInfo() {
        String url = "http://" + ip + ":" + port + "/api/janus/websocket-sockjs";
        Map<String, String> params = Maps.newHashMap();
        params.put("token", token);
        params.put("uuid", uuid);
        System.out.println("请求Janus API获得Websocket信息");
        System.out.println("请求URl为:" + url);
        JsonElement jsonElement = HttpLib.get(url, params);
        if (jsonElement != null) {
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            Object code = jsonObject.get("code");
            System.out.println("请求完成，请求返回code为:" + code);

            JsonObject dataObject = jsonObject.get("data").getAsJsonObject();
            String websocket = dataObject.get("websocket").getAsString();
            String topic = dataObject.get("topic").getAsString();


            if (websocket != null && topic != null) {
                System.out.println("准备创建WebSocket连接");
                System.out.println("Websocket地址为:" + websocket);
                System.out.println("Websocket Topic为:" + topic);
                System.out.println(websocket);
                System.out.println(topic);
                subscribeMessage(websocket, topic);
            }

        }
    }

    public void subscribeMessage(String websocket, final String topic) {
        Transport webSocketTransport = new WebSocketTransport(new StandardWebSocketClient());
        List<Transport> transports = Collections.singletonList(webSocketTransport);

        SockJsClient sockJsClient = new SockJsClient(transports);
        WebSocketStompClient stompClient = new WebSocketStompClient(sockJsClient);

        ListenableFuture<StompSession> f = stompClient.connect(websocket, headers, new MyHandler());

        f.addCallback(new ListenableFutureCallback<StompSession>() {
            @Override
            public void onFailure(Throwable throwable) {
                System.out.printf("case in ...");
            }

            @Override
            public void onSuccess(StompSession stompSession) {
                stompSession.subscribe(topic, new StompFrameHandler() {

                    public Type getPayloadType(StompHeaders stompHeaders) {
                        return byte[].class;
                    }

                    public void handleFrame(StompHeaders stompHeaders, Object o) {
                        String value = new String((byte[]) o);
                        System.out.println(value);
                    }
                });
            }
        });
    }
}
